package com.shaveesha.todoapplication.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.shaveesha.todoapplication.helpers.NoteDatabaseHelper
import com.shaveesha.todoapplication.databinding.FragmentAddNoteBinding
import com.shaveesha.todoapplication.models.Note

class AddNoteFragment : Fragment() {

    private var _binding: FragmentAddNoteBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: NoteDatabaseHelper
    private var noteId: Int = -1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddNoteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = NoteDatabaseHelper(view.context)

        noteId = requireArguments().getInt("note_id", -1)
        if (noteId != -1) {
            val updatingObj = db.getNoteById(noteId)
            binding.titleEditText.setText(updatingObj.title)
            binding.contentEditText.setText(updatingObj.content)
            binding.addNoteHeading.text = "Update Note"
        }

        binding.btnSave.setOnClickListener {
            val title = binding.titleEditText.text.toString()
            val content = binding.contentEditText.text.toString()

            if (noteId == -1) {
                val note = Note(0, title, content)
                db.insertNote(note)

                Toast.makeText(context, "Note Saved Successfully.", Toast.LENGTH_LONG).show()
            } else {
                val updateNote = Note(noteId, title, content)
                db.updateNote(updateNote)

                Toast.makeText(context, "Note Updated Successfully.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}