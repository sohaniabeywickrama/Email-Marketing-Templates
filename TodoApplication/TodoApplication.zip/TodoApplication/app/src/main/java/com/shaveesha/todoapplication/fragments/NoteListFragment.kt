package com.shaveesha.todoapplication.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.shaveesha.todoapplication.R
import com.shaveesha.todoapplication.adapters.NotesAdapter
import com.shaveesha.todoapplication.databinding.FragmentNoteListBinding
import com.shaveesha.todoapplication.helpers.NoteDatabaseHelper

class NoteListFragment : Fragment() {

    private var _binding: FragmentNoteListBinding? = null

    private val binding get() = _binding!!

    private lateinit var db: NoteDatabaseHelper
    private lateinit var notesAdapter: NotesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentNoteListBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        db = NoteDatabaseHelper(requireContext())
        notesAdapter = NotesAdapter(db.getAllNotes(), requireContext())

        binding.rvNotes.layoutManager = LinearLayoutManager(requireContext())
        binding.rvNotes.adapter = notesAdapter
        binding.btnAddNote.setOnClickListener {
            val bundle = bundleOf("note_id" to -1)
            findNavController().navigate(R.id.action_NoteListFragment_to_AddNoteFragment,bundle)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}