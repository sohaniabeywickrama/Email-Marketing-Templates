package com.shaveesha.todoapplication.models

data class Note(
    val id: Int,
    val title: String,
    val content: String
)
